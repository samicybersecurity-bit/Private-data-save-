# My Data Vault — Modern Cloud Storage App

A mobile-first Bengali-friendly HTML app packaged as Android APK with Capacitor and GitHub Actions.

## Included
- Firebase Email/Password authentication
- Private per-user Firestore records
- Optional file uploads to Firebase Storage (15 MB UI limit)
- Live cloud sync, search, edit and delete
- JSON metadata backup export
- Modern dark dashboard and responsive layout
- GitHub Actions debug APK workflow

## Firebase setup
1. Create a project at https://console.firebase.google.com/
2. Authentication → Sign-in method → enable Email/Password.
3. Create a Firestore database.
4. Enable Firebase Storage. Depending on current Firebase requirements, Storage may require a billing-enabled plan. Review Firebase pricing/quotas before use.
5. Project settings → Your apps → add a Web App; copy its config.
6. Replace the placeholders in **www/app.js** (`firebaseConfig`).
7. Publish `firebase/firestore.rules` in Firestore Rules.
8. Publish `firebase/storage.rules` in Storage Rules.

The Storage bucket name shown in your Firebase project settings may end in `.firebasestorage.app`; use the exact `storageBucket` value from the Firebase web config.

## GitHub Actions APK
1. Upload all project files to a GitHub repository on branch `main`.
2. Open Actions and enable workflows if prompted.
3. Run **Build Android APK** (or push a commit to `main`).
4. Open the completed workflow run → Artifacts → download `my-data-vault-debug-apk`.
5. Extract the ZIP and install the debug APK on your Android device.

This workflow produces a **debug/testing APK**, not a signed Play Store release.

## Local development
Requires Node.js 20 and Java 17:
```bash
npm install
npx cap add android
npx cap sync android
```
Open `android/` in Android Studio to run on a device/emulator.

## Security and limitations
- Firebase Authentication and the supplied rules isolate each user's records/files under `users/{uid}`.
- Never publish service-account private keys or admin credentials.
- Firebase web config is public client configuration; Security Rules are essential.
- File uploads are limited to 15 MB in the UI and Storage rules.
- JSON backup exports record metadata and file download URLs; it does not download/copy the actual file bytes. Keep original files backed up separately.
- This starter does not yet include password reset, account deletion, end-to-end encryption, or JSON restore.
