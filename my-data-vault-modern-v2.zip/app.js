import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import {
  getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword,
  onAuthStateChanged, signOut
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import {
  getFirestore, collection, addDoc, query, orderBy, onSnapshot,
  serverTimestamp, deleteDoc, doc
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import {
  getStorage, ref, uploadBytes, getDownloadURL, deleteObject
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js";

// Firebase Console থেকে Web App config নিয়ে নিচের placeholder-গুলো পূরণ করো।
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

const configReady = Object.values(firebaseConfig).every(v => v && !v.startsWith("YOUR_"));
const $ = id => document.getElementById(id);
const authPanel = $("authPanel"), appPanel = $("appPanel");
let auth, db, storage, unsubscribeItems = null, currentUser = null, cachedItems = [];

if (configReady) {
  const app = initializeApp(firebaseConfig);
  auth = getAuth(app); db = getFirestore(app); storage = getStorage(app);
} else {
  $("authMessage").textContent = "প্রথমে app.js ফাইলে Firebase config বসাও। README দেখো।";
  $("loginBtn").disabled = $("registerBtn").disabled = true;
}

$("registerBtn").addEventListener("click", async () => {
  try { await createUserWithEmailAndPassword(auth, $("email").value.trim(), $("password").value); $("authMessage").textContent = "অ্যাকাউন্ট তৈরি হয়েছে।"; }
  catch (e) { $("authMessage").textContent = friendlyError(e); }
});
$("loginBtn").addEventListener("click", async () => {
  try { await signInWithEmailAndPassword(auth, $("email").value.trim(), $("password").value); $("authMessage").textContent = ""; }
  catch (e) { $("authMessage").textContent = friendlyError(e); }
});
$("signOutBtn").addEventListener("click", () => signOut(auth));

if (configReady) onAuthStateChanged(auth, user => {
  currentUser = user;
  authPanel.classList.toggle("hidden", !!user);
  appPanel.classList.toggle("hidden", !user);
  $("signOutBtn").classList.toggle("hidden", !user);
  if (unsubscribeItems) { unsubscribeItems(); unsubscribeItems = null; }
  if (user) listenToItems(user.uid);
});

function listenToItems(uid) {
  const q = query(collection(db, "users", uid, "items"), orderBy("createdAt", "desc"));
  unsubscribeItems = onSnapshot(q, snap => {
    cachedItems = snap.docs.map(d => ({id:d.id, ...d.data()}));
    renderItems();
  }, err => $("itemsList").textContent = friendlyError(err));
}
$("searchInput").addEventListener("input", renderItems);

$("saveBtn").addEventListener("click", async () => {
  const title = $("itemTitle").value.trim(), body = $("itemText").value.trim(), file = $("itemFile").files[0];
  if (!title && !body && !file) { $("saveMessage").textContent = "কমপক্ষে একটি তথ্য বা ফাইল দাও।"; return; }
  $("saveBtn").disabled = true; $("saveMessage").textContent = "Cloud-এ সেভ হচ্ছে...";
  try {
    let fileData = null;
    if (file) {
      if (file.size > 15 * 1024 * 1024) throw new Error("ফাইল ১৫ MB-এর মধ্যে হতে হবে।");
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      const path = `users/${currentUser.uid}/${crypto.randomUUID()}_${safeName}`;
      const fileRef = ref(storage, path);
      await uploadBytes(fileRef, file);
      fileData = {name:file.name, path, url:await getDownloadURL(fileRef), contentType:file.type || "application/octet-stream"};
    }
    await addDoc(collection(db, "users", currentUser.uid, "items"), {
      title, body, file:fileData, createdAt:serverTimestamp()
    });
    $("itemTitle").value = ""; $("itemText").value = ""; $("itemFile").value = "";
    $("saveMessage").textContent = "সফলভাবে Cloud-এ সেভ হয়েছে।";
  } catch (e) { $("saveMessage").textContent = friendlyError(e); }
  finally { $("saveBtn").disabled = false; }
});

function renderItems() {
  const term = $("searchInput").value.trim().toLowerCase();
  const filtered = cachedItems.filter(x => `${x.title||""} ${x.body||""} ${x.file?.name||""}`.toLowerCase().includes(term));
  const list = $("itemsList"); list.replaceChildren();
  if (!filtered.length) { list.textContent = "কোনো ডেটা পাওয়া যায়নি।"; return; }
  for (const item of filtered) {
    const card = document.createElement("article"); card.className = "item";
    const h = document.createElement("h3"); h.textContent = item.title || "Untitled";
    const p = document.createElement("p"); p.textContent = item.body || "";
    card.append(h,p);
    if (item.file?.url) {
      const a = document.createElement("a"); a.href = item.file.url; a.target = "_blank"; a.rel = "noopener noreferrer"; a.textContent = `ফাইল খুলুন: ${item.file.name}`; card.append(a);
    }
    const small = document.createElement("small"); small.textContent = item.createdAt?.toDate ? item.createdAt.toDate().toLocaleString() : "সদ্য যোগ করা"; card.append(small);
    const actions = document.createElement("div"); actions.className = "item-actions";
    const del = document.createElement("button"); del.className = "danger"; del.textContent = "Delete";
    del.addEventListener("click", () => removeItem(item)); actions.append(del); card.append(actions); list.append(card);
  }
}
async function removeItem(item) {
  if (!confirm("এই ডেটা মুছে ফেলবে?")) return;
  try {
    if (item.file?.path) await deleteObject(ref(storage, item.file.path)).catch(e => { if (e.code !== "storage/object-not-found") throw e; });
    await deleteDoc(doc(db, "users", currentUser.uid, "items", item.id));
  } catch (e) { alert(friendlyError(e)); }
}
function friendlyError(e) {
  const map = {"auth/invalid-email":"সঠিক ইমেইল দাও।","auth/weak-password":"পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।","auth/email-already-in-use":"এই ইমেইলে অ্যাকাউন্ট আছে।","auth/invalid-credential":"ইমেইল বা পাসওয়ার্ড সঠিক নয়.","auth/network-request-failed":"ইন্টারনেট সংযোগ পরীক্ষা করো।"};
  return map[e.code] || e.message || "একটি সমস্যা হয়েছে।";
}
