import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore, collection, addDoc, query, orderBy, onSnapshot, serverTimestamp, deleteDoc, doc, updateDoc } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { getStorage, ref, uploadBytes, getDownloadURL, deleteObject } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js";

// Firebase Console থেকে Web App config নিয়ে নিচের placeholder-গুলো পূরণ করো।
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};
const configReady = Object.values(firebaseConfig).every(v => v && !v.startsWith("YOUR_"));
const $ = id => document.getElementById(id);
let auth, db, storage, unsubscribeItems = null, currentUser = null, cachedItems = [], editingId = null;
if (configReady) {
  const app = initializeApp(firebaseConfig);
  auth = getAuth(app); db = getFirestore(app); storage = getStorage(app);
} else {
  $("authMessage").textContent = "শুরু করতে www/app.js ফাইলে Firebase config বসাও। README দেখো।";
  $("loginBtn").disabled = $("registerBtn").disabled = true;
}
$("registerBtn").addEventListener("click", async () => {
  try { await createUserWithEmailAndPassword(auth, $("email").value.trim(), $("password").value); $("authMessage").textContent = "অ্যাকাউন্ট তৈরি হয়েছে।"; }
  catch (e) { $("authMessage").textContent = friendlyError(e); }
});
$("loginBtn").addEventListener("click", async () => {
  try { await signInWithEmailAndPassword(auth, $("email").value.trim(), $("password").value); $("authMessage").textContent = ""; }
  catch (e) { $("authMessage").textContent = friendlyError(e); }
});
$("signOutBtn").addEventListener("click", () => signOut(auth));
if (configReady) onAuthStateChanged(auth, user => {
  currentUser = user;
  $("authPanel").classList.toggle("hidden", !!user);
  $("appPanel").classList.toggle("hidden", !user);
  $("signOutBtn").classList.toggle("hidden", !user);
  if (unsubscribeItems) { unsubscribeItems(); unsubscribeItems = null; }
  if (user) listenToItems(user.uid);
});
function listenToItems(uid) {
  const q = query(collection(db, "users", uid, "items"), orderBy("createdAt", "desc"));
  unsubscribeItems = onSnapshot(q, snap => {
    cachedItems = snap.docs.map(d => ({id:d.id, ...d.data()}));
    renderItems();
  }, err => $("itemsList").textContent = friendlyError(err));
}
$("searchInput").addEventListener("input", renderItems);
$("saveBtn").addEventListener("click", saveItem);
$("cancelEditBtn").addEventListener("click", resetEditor);
$("exportBtn").addEventListener("click", exportBackup);

async function saveItem() {
  const title = $("itemTitle").value.trim(), body = $("itemText").value.trim(), file = $("itemFile").files[0];
  if (!title && !body && !file && !editingId) { $("saveMessage").textContent = "কমপক্ষে একটি তথ্য বা ফাইল দাও।"; return; }
  $("saveBtn").disabled = true; $("saveMessage").textContent = "Cloud-এ সেভ হচ্ছে...";
  try {
    let oldItem = cachedItems.find(x => x.id === editingId), fileData = oldItem?.file || null;
    if (file) {
      if (file.size > 15 * 1024 * 1024) throw new Error("ফাইল ১৫ MB-এর মধ্যে হতে হবে।");
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      const path = `users/${currentUser.uid}/${crypto.randomUUID()}_${safeName}`;
      const fileRef = ref(storage, path);
      await uploadBytes(fileRef, file);
      fileData = {name:file.name, path, url:await getDownloadURL(fileRef), contentType:file.type || "application/octet-stream"};
    }
    const payload = {title, body, file:fileData, updatedAt:serverTimestamp()};
    if (editingId) {
      await updateDoc(doc(db, "users", currentUser.uid, "items", editingId), payload);
      if (file && oldItem?.file?.path) await deleteObject(ref(storage, oldItem.file.path)).catch(()=>{});
      $("saveMessage").textContent = "ডেটা আপডেট হয়েছে।";
    } else {
      await addDoc(collection(db, "users", currentUser.uid, "items"), {...payload, createdAt:serverTimestamp()});
      $("saveMessage").textContent = "সফলভাবে Cloud-এ সেভ হয়েছে।";
    }
    resetEditor(false);
  } catch (e) { $("saveMessage").textContent = friendlyError(e); }
  finally { $("saveBtn").disabled = false; }
}
function resetEditor(clearMessage=true) {
  editingId = null; $("itemTitle").value = ""; $("itemText").value = ""; $("itemFile").value = "";
  $("editorHeading").textContent = "নতুন ডেটা যোগ করো"; $("saveBtn").innerHTML = 'Save to cloud <span>→</span>';
  $("cancelEditBtn").classList.add("hidden");
  if (clearMessage) $("saveMessage").textContent = "";
}
function startEdit(item) {
  editingId = item.id; $("itemTitle").value = item.title || ""; $("itemText").value = item.body || "";
  $("itemFile").value = ""; $("editorHeading").textContent = "ডেটা এডিট করো";
  $("saveBtn").textContent = "Update in cloud"; $("cancelEditBtn").classList.remove("hidden");
  $("saveMessage").textContent = "নতুন ফাইল দিলে আগের ফাইলটি বদলে যাবে।";
  $("itemTitle").focus(); window.scrollTo({top:0,behavior:"smooth"});
}
function renderItems() {
  const term = $("searchInput").value.trim().toLowerCase();
  const filtered = cachedItems.filter(x => `${x.title||""} ${x.body||""} ${x.file?.name||""}`.toLowerCase().includes(term));
  $("totalCount").textContent = cachedItems.length;
  $("fileCount").textContent = cachedItems.filter(x => x.file?.url).length;
  const list = $("itemsList"); list.replaceChildren();
  if (!filtered.length) {
    const empty = document.createElement("div"); empty.className = "empty-state";
    empty.textContent = term ? "এই নামে কোনো ডেটা পাওয়া যায়নি।" : "এখনো কিছু সেভ করা হয়নি। প্রথম ডেটাটি যোগ করো!";
    list.append(empty); return;
  }
  for (const item of filtered) {
    const card = document.createElement("article"); card.className = "item";
    const h = document.createElement("h3"); h.textContent = item.title || "Untitled";
    card.append(h);
    if (item.body) { const p = document.createElement("p"); p.textContent = item.body; card.append(p); }
    if (item.file?.url) { const a = document.createElement("a"); a.href = item.file.url; a.target = "_blank"; a.rel = "noopener noreferrer"; a.textContent = `↗ ${item.file.name}`; card.append(a); }
    const small = document.createElement("small"); small.textContent = item.createdAt?.toDate ? item.createdAt.toDate().toLocaleString() : "সদ্য যোগ করা"; card.append(small);
    const actions = document.createElement("div"); actions.className = "item-actions";
    const edit = document.createElement("button"); edit.className = "edit-btn"; edit.textContent = "Edit"; edit.addEventListener("click",()=>startEdit(item));
    const del = document.createElement("button"); del.className = "danger"; del.textContent = "Delete"; del.addEventListener("click",()=>removeItem(item));
    actions.append(edit,del); card.append(actions); list.append(card);
  }
}
async function removeItem(item) {
  if (!confirm("এই ডেটা মুছে ফেলবে?")) return;
  try {
    if (item.file?.path) await deleteObject(ref(storage,item.file.path)).catch(e=>{if(e.code!=="storage/object-not-found")throw e;});
    await deleteDoc(doc(db,"users",currentUser.uid,"items",item.id));
    if (editingId===item.id) resetEditor();
  } catch(e) { alert(friendlyError(e)); }
}
function exportBackup() {
  const data = cachedItems.map(({id,title,body,file,createdAt})=>({
    id,title,body,file:file?{name:file.name,url:file.url,contentType:file.contentType}:null,
    createdAt:createdAt?.toDate?createdAt.toDate().toISOString():null
  }));
  const blob = new Blob([JSON.stringify({app:"My Data Vault",exportedAt:new Date().toISOString(),items:data},null,2)],{type:"application/json"});
  const url=URL.createObjectURL(blob), a=document.createElement("a"); a.href=url; a.download="my-data-vault-backup.json"; a.click(); URL.revokeObjectURL(url);
}
function friendlyError(e) {
  const map={"auth/invalid-email":"সঠিক ইমেইল দাও।","auth/weak-password":"পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।","auth/email-already-in-use":"এই ইমেইলে অ্যাকাউন্ট আছে।","auth/invalid-credential":"ইমেইল বা পাসওয়ার্ড সঠিক নয়।","auth/network-request-failed":"ইন্টারনেট সংযোগ পরীক্ষা করো।","permission-denied":"Firebase Security Rules পরীক্ষা করো।"};
  return map[e.code]||e.message||"একটি সমস্যা হয়েছে।";
}
